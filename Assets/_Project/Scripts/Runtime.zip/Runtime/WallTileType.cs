public enum WallTileType
{
    None = 0,
    Straight = 1,
    SmallCurve = 2,
    StrongCurve = 3,
    Split = 4
}
