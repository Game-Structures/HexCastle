public enum EnemyTargetKind
{
    Ground = 0,
    Air = 1
}

public enum AttackTargetKind
{
    All = 0,
    Ground = 1,
    Air = 2
}
