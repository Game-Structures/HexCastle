public static class GameState
{
    public static bool IsGameOver;

    public static void Reset()
    {
        IsGameOver = false;
    }
}
