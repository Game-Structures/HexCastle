namespace HexCastle.Map
{
    public enum MapTerrainType
    {
        Normal = 0,
        Water = 1,
        Mountain = 2,
        Forest = 3,
    }
}
