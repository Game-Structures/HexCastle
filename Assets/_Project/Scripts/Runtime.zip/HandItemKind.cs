public enum HandItemKind
{
    None = 0,
    Wall = 1,
    Tower = 2,
    Combo = 3, // Wall + Tower
}
