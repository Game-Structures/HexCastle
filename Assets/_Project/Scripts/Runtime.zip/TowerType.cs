public enum TowerType
{
    Archer = 0,
    Artillery = 1,
    Magic = 2,
    Flame = 3
}
