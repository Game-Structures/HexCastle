using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

public class BuildingEffectsManager : MonoBehaviour
{
    public static BuildingEffectsManager Instance { get; private set; }

    [Header("Gold bank reference (перетащи сюда объект с компонентом GoldBank)")]
    public MonoBehaviour goldBank;

    [Header("Tuning")]
    public int bankCoinsPerBuildRound = 5;

    private readonly Dictionary<BuildingId, int> _counts = new Dictionary<BuildingId, int>();

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
    }

    private void Update()
    {
        // ТЕСТ: в Play нажми F6 – начислит монеты за Банки
        if (Input.GetKeyDown(KeyCode.F6))
        {
            OnBuildRoundStart();
        }
    }

    public void RegisterBuilding(CastleBuilding b)
    {
        if (b == null) return;
        Add(b.id, +1);
        Debug.Log($"[BuildingEffects] Register {b.id} -> count={GetCount(b.id)}");
    }

    public void UnregisterBuilding(CastleBuilding b)
    {
        if (b == null) return;
        Add(b.id, -1);
        Debug.Log($"[BuildingEffects] Unregister {b.id} -> count={GetCount(b.id)}");
    }

    public int GetCount(BuildingId id)
    {
        int v;
        return _counts.TryGetValue(id, out v) ? v : 0;
    }

    private void Add(BuildingId id, int delta)
    {
        int v = GetCount(id) + delta;
        if (v < 0) v = 0;
        _counts[id] = v;
    }

    // Будем вызывать в начале строительного раунда (пока тестим через F6)
    public void OnBuildRoundStart()
    {
        int banks = GetCount(BuildingId.Bank);
        int add = bankCoinsPerBuildRound * banks;

        Debug.Log($"[BuildingEffects] BuildRoundStart: banks={banks}, addGold={add}");

        if (add > 0)
            TryAddGold(add);
    }

    private void TryAddGold(int amount)
    {
        if (goldBank == null)
        {
            Debug.LogWarning("[BuildingEffects] goldBank is not assigned");
            return;
        }

        // Пытаемся вызвать один из типичных методов: Add / AddGold / AddCoins / AddMoney
        var t = goldBank.GetType();
        string[] methods = { "Add", "AddGold", "AddCoins", "AddMoney" };

        foreach (var name in methods)
        {
            var mi = t.GetMethod(name, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            if (mi == null) continue;

            var p = mi.GetParameters();
            if (p.Length == 1 && (p[0].ParameterType == typeof(int) || p[0].ParameterType == typeof(float)))
            {
                object arg = (p[0].ParameterType == typeof(int)) ? (object)amount : (object)(float)amount;
                mi.Invoke(goldBank, new[] { arg });
                Debug.Log($"[BuildingEffects] Gold added via {t.Name}.{name}({amount})");
                return;
            }
        }

        Debug.LogError($"[BuildingEffects] Can't find suitable add method on {t.Name}. " +
                       $"Expected one of: Add(int/float), AddGold(int/float), AddCoins(int/float), AddMoney(int/float)");
    }
}
