public enum BuildingId
{
    Bank = 1,
    Quarry = 2,
    Telescope = 3,
    Forge = 4,
    ArtilleryUnlock = 5
}
