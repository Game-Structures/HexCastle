public static class PlacementInputLock
{
    // true = идет размещение тайла/башни, камеру блокируем
    public static bool IsPlacing;
}
