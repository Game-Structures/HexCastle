public enum HandItemKind
{
    None = 0,
    Wall = 1,
    Tower = 2,
    Combo = 3, // Wall + Tower

    WallPair = 4, // NEW: 2 соседних тайла стены одной картой
}
