public enum TowerUpgradeId
{
    DamagePlus10,
    FireRatePlus10,
    RangePlus1,
    CritChancePlus10,
    CritDamagePlus25,
}
